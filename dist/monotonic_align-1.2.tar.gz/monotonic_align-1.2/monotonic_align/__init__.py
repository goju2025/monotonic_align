import pkg_resources

__version__ = pkg_resources.get_distribution('monotonic_align').version

from monotonic_align.mas import *
